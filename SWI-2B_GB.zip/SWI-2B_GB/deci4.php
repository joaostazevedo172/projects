<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão4 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite A: 
	<input type="text" name="n1">
	<br/>
	<br/>
	Digite B: 
	<input type="text" name="n2">
	<br/>
    <br/>
    Digite C: 
	<input type="text" name="n3">
    <br><br>
    Digite D: 
	<input type="text" name="n4">
    <br><br>
    <input type="submit" value="Calcular">
	<br><br>
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['n2']) and isset ($_POST['n3']) and isset ($_POST['n4']))
            {
				
					$val1 = $_POST['n1'];
   					$val2 = $_POST['n2'];
    				$val3 =  $_POST['n3'];
                    $val4 =  $_POST['n4'];
    				$result1 = $val1 + $val3;
                    $result2 = $val2 * $val4;

				if ($result1 > $result2)
                {
                    echo "A + C é maior que B * D";
                }
                else if ($result1 < $result2)
                {
                    echo "A + C é menor que B * D";
                }
                else
                {
                    echo "A + C é igual a B * D";
                }
			
            
            }
	
?>
	

</body>
</html>
