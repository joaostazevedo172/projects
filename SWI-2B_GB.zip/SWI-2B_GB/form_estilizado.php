<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário</title>
    <link rel="stylesheet" href="./estilos.css">
</head>

<body>
    <form method="post">
        <div class="caixa__login">
            <h2>Dados</h2>
            <form>
                <div class="caixa__login-input">
                    <input type="text" required name="email" />
                    <label>Email</label>
                </div>
                <div class="caixa__login-input">
                    <input type="password" required name="senha" />
                    <label>Senha</label>
                </div>
                <div>
                    <input type="submit" required value="Enviar" />
                </div>
                </a>
            </form>
        </div>
    </form>

    <?php

    include "conexao2.php";

    if (isset($_POST['email']) and isset($_POST['senha'])) {
        $email = $_POST['email'];
        $sen = $_POST['senha'];

        if (($email == "") || ($sen == "") ) {
            echo "<script>alert('Campos nao podem ser vazios!!!');history.go(-1);</script>";
        } else {

            try {

                $estilo = $conn->prepare('INSERT INTO estilo (email, senha) VALUES 
            (:email, :senha)');

                $estilo->execute(array(
                    ':email' => $email,
                    ':senha' => $sen,
                ));


                if ($estilo->rowCount() == 1) {
                    echo "<script>alert('Incluido com sucesso!!!');history.go(-1);</script>";
                } else {
                    echo "<script>alert('Erro ao incluir');history.go(-1);</script>";
                }
            } catch (PDOException $e) {
                echo 'ERROR: ' . $e->getMessage();
            }
        }
    }
    ?>
</body>

</html>