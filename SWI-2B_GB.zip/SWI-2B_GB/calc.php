<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form.com</title>
    <form method="post" action="calc.php">
        <input type="text" name="n" style="border-radius: 5px;">
        <br>
        <input type="text" name="n2" style="border-radius: 5px;">
        <br>
        <input type="submit" value="calcular" name="bot">
    </form>
</head>

<body>
    
        <?php
         if (isset ($_POST['n']) and isset ($_POST['n2']))
         {
            $a = $_POST['n'];
            $b = $_POST['n2'];
            $c =  $a + $b;
            echo  "This is the result of the numbers: <br>", $c;
         }
    ?>
    

</body>

</html>