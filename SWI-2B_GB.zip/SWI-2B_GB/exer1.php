<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exer 1 php </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite a primeira nota: 
	<input type="text" name="txt_valor1">
	<br/>
	<br/>
	Digite a segunda nota: 
	<input type="text" name="txt_valor2">
	<br/>
    <br/>
    Digite a terceira nota: 
	<input type="text" name="txt_valor3">
    <br><br>
    <input type="submit" value="calcular" name="result">
	<br><br>
	Resultado:
	</form>
	<p id="mostrarResultados"></p>

	<?php

    if (isset ($_POST['txt_valor1']) and isset ($_POST['txt_valor2']) and isset ($_POST['txt_valor3']) and isset ($_POST['result']))
            {
				
					$a = $_POST['txt_valor1'];
   					$b = $_POST['txt_valor2'];
    				$c =  $_POST['txt_valor3'];
    				$result = $_POST['result'];

				function soma ($a, $b, $c)
				{
					

					$result = ($a + $b + $c)/3;

					echo $result;
                	
				}

				echo soma ($a, $b, $c);
			
            
            }
	
?>
	

</body>
</html>
