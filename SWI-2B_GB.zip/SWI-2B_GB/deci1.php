<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão1</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite um valor: 
	<input type="text" name="v1">
	<br><br>
    <input type="submit" value="Calcular" name="val">
	

	<?php

    if (isset ($_POST['v1']) and isset ($_POST['val']))
            {
				
					$a = $_POST['v1'];
                 
                    if ($a > 10)
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "O valor é maior que 10";
                    }
                    else 
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "O valor é menor que 10";
                    }
			
            
            }
	
?>
	

</body>
</html>
