<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>raio</title>
</head>
<body>
    <form method="post">
        Escreva o raio do círculo:
        <input type="text" name="r">
        <input type="submit" value="Enviar">
    </form>

    <?php
    if (isset ($_POST['n']))

    {

    
        $raio = $_POST['r'];
        $pi = 3.14159265;
        $per = 2 * $pi * $raio;
        $area = $pi * $raio * $raio;

        echo "Este é o valor do perímetro " . $per;
        echo "<br>";
        echo "Este é o valor da área " . $area;
    }

    ?>
    
</body>
</html>