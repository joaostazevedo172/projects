<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form.com</title>
    <form method="post">
        Primeiro Número: <input type="text" name="n" style="border-radius: 5px;"><br>
        Segundo Número: <input type="text" name="n2" style="border-radius: 5px;"><br>
        <input type="submit" value="+" name="operacao">
        <input type="submit" value="-" name="operacao">
        <input type="submit" value="*" name="operacao">
        <input type="submit" value="/" name="operacao">
    </form>
</head>

<body>
    
        <?php
        $a = $_POST['n'];
        $b = $_POST['n2'];
        $c =  $_POST['operacao'];
            if (isset ($_POST['n']) and isset ($_POST['n2']) and isset ($_POST['operacao']))
            {
                if ($c == '+')
                $c = $a + $b;
                else if ($c == '-')
                $c = $a - $b; 
                else if ($c == '*')
                $c = $a * $b; 
                else if ($c == '/')
                $c = $a - $b;  
                
                echo "O resultado da operação foi:", $c;
            }
            
    ?>
    

</body>

</html>