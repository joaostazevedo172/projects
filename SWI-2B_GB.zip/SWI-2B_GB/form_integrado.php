<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>formulário</title>

    <style>
        .f1 {
            margin: auto;
            width: 300px;
            background-color: white;
        }
    </style>
</head>

<body>
    <form method="post">
        <center>
            <h1><b>Formulário:</b></h1>
        </center>
        <br><br>
        <fieldset class="f1">
            <legend>Dados Pessoais</legend>
            Nome: <input type="text" name="nome">
            <br><br>
            Endereço: <input type="text" name="end">
            <br><br>
            Cidade: <input type="text" name="cid">
            <br><br>
            Estado: <select name="estado">
                <option value="SP">SP</option>
                <option value="RJ">RJ</option>
                <option value="AM">AM</option>
                <option value="AC">AC</option>
                <option value="RO">RO</option>
                <option value="RR">RR</option>
                <option value="PA">PA</option>
                <option value="TO">TO</option>
                <option value="AP">AP</option>
                <option value="MT">MT</option>
                <option value="MS">MS</option>
                <option value="GO">GO</option>
                <option value="ES">ES</option>
                <option value="MG">MG</option>
                <option value="PR">PR</option>
                <option value="SC">SC</option>
                <option value="RS">RS</option>
                <option value="MA">MA</option>
                <option value="PI">PI</option>
                <option value="BA">BA</option>
                <option value="CE">CE</option>
                <option value="RN">RN</option>
                <option value="PB">PB</option>
                <option value="PE">PE</option>
                <option value="AL">AL</option>
                <option value="SE">SE</option>
            </select>
        </fieldset>
        <br><br>
        <fieldset class="f1">
            <legend>Dados Profissionais</legend>

            Natureza do cargo
            <br>
            <input type="radio" name="cargo" value="Gerência">Gerência
            <input type="radio" name="cargo" value="Financeiro">Financeiro
            <input type="radio" name="cargo" value="Recepção">Recepção
            <input type="radio" name="cargo" value="Administrativo">Administrativo
            <input type="radio" name="cargo" value="Jurídico">Jurídico
            <br><br>
            Área de interesse
            <br>
            <input type="checkbox" name="area[]" value="Computação">Computação
            <input type="checkbox" name="area[]" value="Biologia">Biologia
            <input type="checkbox" name="area[]" value="Meio-Ambiente">Meio-Ambiente
            <input type="checkbox" name="area[]" value="Engenharia">Engenharia
            <input type="checkbox" name="area[]" value="História">História
            <br><br>
            Mini Currículo:
            <textarea id="w3review" name="curriculo" rows="4" cols="50">
            </textarea>
        </fieldset>
        <br>
        <center><input type="submit" value="Enviar"></center>
        <br>
        <center><input type="submit" value="Limpar"></center>
    </form>

    <?php

    include "conexao.php";

    if (
        isset($_POST['nome']) and isset($_POST['end']) and isset($_POST['cid'])
        and isset($_POST['estado']) and isset($_POST['cargo']) and isset($_POST['area'])
        and isset($_POST['curriculo'])
    ) {

        $name = $_POST["nome"];
        $endereco = $_POST["end"];
        $cidade = $_POST["cid"];
        $est = $_POST["estado"];
        $car = $_POST["cargo"];
        $are = $_POST["area"];
        $cur = $_POST["curriculo"];

        if (($name == "") || ($endereco == "") || ($cidade == "") || ($est == "") || ($car == "") || ($are == "") || ($cur == "")) {
            echo "<script>alert('Campos nao podem ser vazios!!!');history.go(-1);</script>";
        } else

            try {
                $pessoal = $conn->prepare('INSERT INTO pessoal (nome, cidade, endereco, estado, natureza_cargo, mini) VALUES 
            (:nome, :cidade, :endereco, :estado, :natureza_cargo, :mini)');

                $pessoal->execute(array(
                    ':nome' => $name,
                    ':cidade' => $cidade,
                    ':endereco' => $endereco,
                    ':estado' => $est,
                    ':natureza_cargo' => $car,
                    ':mini' => $cur

                ));


                if ($pessoal->rowCount() == 1) {
                    $codigo = $conn->lastInsertId();
                    for ($i = 0; $i < count($are); $i++) {
                        try {
                            $area = $conn->prepare('INSERT INTO interesse (nome, id_pessoal) VALUES 
                        (:nome, :id_pessoal)');

                            $area->execute(array(
                                ':nome' => $are[$i],
                                ':id_pessoal' => $codigo,


                            ));
                        } catch (PDOException $e) {
                            echo 'ERROR: ' . $e->getMessage();
                        }
                    }

                    echo "<script>alert('Incluido com sucesso!!!');history.go(-1);</script>";
                } else {
                    echo "<script>alert('Erro ao incluir');history.go(-1);</script>";
                }
            } catch (PDOException $e) {
                echo 'ERROR: ' . $e->getMessage();
            }

            if ($interesse->rowCount()>1)
            {  
                echo "<script>alert('Incluido com sucesso!!!');history.go(-1);</script>";
            }
            else 
            {
                echo "<script>alert('Erro ao incluir');history.go(-1);</script>";
            }

        for ($i = 0; $i < count($are); $i++) {
            echo $are[$i];
        }
        echo "<br>";
    }
    ?>


</body>

</html>