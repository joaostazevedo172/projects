<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão6 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite a nota 1: 
	<input type="text" name="n1">
	<br/>
	<br/>
	Digite a nota 2: 
	<input type="text" name="n2">
	<br/>
    <br/>
    Digite a nota 3: 
	<input type="text" name="n3">
    <br><br>
    Digite a nota 4: 
	<input type="text" name="n4">
    <br><br>
    <input type="submit" value="Calcular">
	<br><br>
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['n2']) and isset ($_POST['n3']) and isset ($_POST['n4']))
            {
				
					$val1 = $_POST['n1'];
   					$val2 = $_POST['n2'];
    				$val3 =  $_POST['n3'];
                    $val4 =  $_POST['n4'];
    				$media = ($val1 + $val2 + $val3 + $val4)/4;
                  

				if ($media >= 7)
                {
                    echo $media;
                    echo "<br>";
                    echo "Aluno Aprovado";
                }
               
                else
                {
                    echo $media;
                    echo "<br>";
                    echo "Aluno Reprovado";
                }
			
            
            }
	
?>
	

</body>
</html>
