<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão7 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite a altura: 
	<input type="text" name="n1">
	<br/>
	<br/>
	Qual seu sexo? Digite (1) para masculino e (2) para feminino: 
	<input type="text" name="n2">
	<br/>
    <br/>
    <input type="submit" value="Calcular">
	<br><br>
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['n2']))
            {
				
					$alt = $_POST['n1'];
   					$sex = $_POST['n2'];
    				$fem;
					$masc;

				if ($sex == 1)
                {
                    $masc = (72.7 * $alt) - 58;
                    echo $masc;
                }
                else
                {
                    $fem = (62.1 * $alt) - 44.7;
                    echo $fem;
                }

                
                
			
            
            }
	
?>
	

</body>
</html>
