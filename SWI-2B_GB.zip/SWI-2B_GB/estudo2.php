<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>informado</title>
</head>
<body>
    <form method="post">
        Digite um número:
        <input type="text" name="n1">
        <input type="submit" value="Enviar"> 
    </form>

    <?php

    if (isset ($_POST['n1']))
    {

    
        $num1 = $_POST['n1'];

        echo "O número informado foi: " . $num1;
    }
    ?>
    
</body>
</html>