<?php
// Faz uma cópia do conteúdo do arquivo "conexao.php""
// para o ponto(linha onde está o include) do arquivo atual
include "conexao.php";
// $nome é a variável que irá receber os dados
// digitados no formulário através do INPUT
// $_POST["nome"] está recebendo os dados do 
// INPUT que tem o name = "nome"
$nome = $_POST["nome"];
$telefone = $_POST["telefone"];
$email = $_POST["email"];
if (($nome=="") || ($telefone=="") || ($email=="")){
    echo "<script>alert('Campos nao podem ser vazios!!!');history.go(-1);</script>";
} else {
    // TRY tenta executar todas as instruções que estão entre
    // suas chaves. Caso não consiga, irá executar o que
    // está entre as chaves do CATCH
try{
    // $agenda é uma variável que irá receber a preparação
    // da instrução SQL que está disponível através da
    // variável $conn (que realizou a conexão ao MySQL)
    $agenda = $conn->prepare('INSERT INTO agenda (nome, telefone, email) VALUES 
    (:nome, :telefone, :email)');
    // todas as informações que estão com : antes do nome
    // são parâmetros da instrução
    // Esses parâmetros devem receber o conteúdo das
    // variáveis como no exemplo abaixo.
    $agenda->execute(array(
    ':nome' => $nome,
    ':telefone' => $telefone,
    ':email' => $email
    ));

    // Na instrução abaixo, a variável $agenda recebeu
    // o resultado do comando SQL anterior.
    // a parte ->rowCount() serve para contar quantas
    // linhas foram afetadas pelo comando SQL.
    // Caso o número de linhas afetadas seja == 1 é
    // um sinal que o comando INSERT funcionou, caso
    // contrário gerou um erro
    if ($agenda->rowCount()==1){
        echo "<script>alert('Incluido com sucesso!!!');history.go(-1);</script>";
    } else {
        echo "<script>alert('Erro ao incluir');history.go(-1);</script>";
    }
    // CATCH é o tratamento de erro caso o TRY  não consiga
    // executar os comando dentro das chaves dele.
} catch(PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
}
}
?>