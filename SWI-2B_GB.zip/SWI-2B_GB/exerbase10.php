<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico10 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite o comprimento: 
	<input type="text" name="comprimento">
	<br/>
	<br/>
	Digite a largura: 
	<input type="text" name="largura">
	<br/>
    <br/>
    Digite a altura: 
	<input type="text" name="altura">
	<br/>
	<br/>
    <input type="submit" name="volume" value="Calcular">
    <p id="operacao">Volume:</p>
    </form>

	<?php

    if (isset ($_POST['comprimento']) and isset ($_POST['largura']) and isset ($_POST['altura']) and isset ($_POST['volume']))
            {
				
					$a = $_POST['comprimento'];
   					$b = $_POST['largura'];
    				$c =  $_POST['altura'];
    				$result = $_POST['volume'];

				function soma ($a, $b, $c)
				{
					

					$result = ($a * $b * $c);

					echo $result;
                	
				}

				echo soma ($a, $b, $c);
			
            
            }
	
?>
</body>
</html>
