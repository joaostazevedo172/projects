<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form.com</title>
    <form method="post">
    <input type="text" name="n" style="border-radius: 5px;"><br>
    <br><br>
    <input type="submit" value="calcular" name="operacao">
    <br><br>
    </form>
    <style>
        table,td,tr
        {
            border-collapse: collapse;
            border: 2px solid white;
            color: white;
            margin: auto;
        }

        form 
        {
            margin: auto;
            
        }
    </style>
</head>

<body background="https://www.bing.com/th/id/OGC.26ebf38bac406b7afd6a892e45a24e7e?pid=1.7&rurl=https%3a%2f%2fgifimage.net%2fwp-content%2fuploads%2f2017%2f11%2fel-universo-gif-10.gif&ehk=U%2biJJNQXZMXTsN5KaZQz7cHjmVRepmla3ZNyv2Mmlv0%3d">
<table>  
<?php
        if (isset ($_POST['n']))
        {
                $num = $_POST['n'];
        
                for ($cont = 0; $cont <= 10; $cont++)
                { 
                    $result = $num * $cont;
                     
                    echo "<tr><td>".  $num,"x", $cont, "=", $result, "<td><tr>";
                }


                   
                
                
            
        
        }
        ?>
    </table>
    

</body>

</html>