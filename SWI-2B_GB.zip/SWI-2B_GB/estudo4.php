<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>quadrado</title>
</head>
<body>
    <form method="post">
        Digite o valor da base do quadrado:
        <br>
        <input type="text" name="b">
        <br>
        <br>
        Digite a altura do quadrado:
        <br>
        <input type="text" name="alt">
        <br>
        <br>
        <input type="submit" value="Enviar">
    </form>

    <?php
        if (isset ($_POST['b']) and isset ($_POST['alt']))
        {
            $base = $_POST['b'];
            $altura = $_POST['alt'];
            $a_quad = $base * $altura;

            echo "Este é o valor da área do quadrado: " . $a_quad;
            echo "<br>";
            echo "Este é o dobro do valor da área: " . $a_quad * 2;

        }
    ?>
    
</body>
</html>