<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exer 3 php </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite o primeiro valor: 
	<input type="text" name="txt_valor1">
	<br/>
	<br/>
	Digite o segundo valor: 
	<input type="text" name="txt_valor2">
	<br/>
    <br/>
    Digite o terceiro valor: 
	<input type="text" name="txt_valor3">
	<br/>
	<br/>
	Resultado:
	<br/>
	<br/>
    <input type="submit" value="calcular" name="result">
	<br>
    </form>

	<?php

    if (isset ($_POST['txt_valor1']) and isset ($_POST['txt_valor2']) and isset ($_POST['txt_valor3']) and isset ($_POST['result']))
            {
				
					$a = $_POST['txt_valor1'];
   					$b = $_POST['txt_valor2'];
    				$c =  $_POST['txt_valor3'];
    				$result = $_POST['result'];

				function soma ($a, $b, $c)
				{
					

					$a = $a * 2;
                    $b = $b * 3;
                    $c = $c * 5;
                	
                    $result = (($a + $b + $c)/10);

					echo $result;
				}

				echo soma ($a, $b, $c);
			
            
            }
	
?>

</body>
</html>
