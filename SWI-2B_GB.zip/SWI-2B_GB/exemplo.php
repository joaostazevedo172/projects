<?php
    $a = $_POST ['n'];
    $b = $_POST ['n2'];
    $c =  $a + $b;
    
    echo  "This is the result of the numbers: <br>", $c;
?>