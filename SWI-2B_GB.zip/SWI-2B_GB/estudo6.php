<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>temperatura</title>
</head>
<body>
    <form method="post">
        Digite a temperatura em graus Farenheit:
        <input type="text" name="f">
        <br>
        <br>
        <input type="submit">
    </form> 

    <?php

    if (isset ($_POST['f']))
    {
        $f = $_POST['f'];
        $c = (5*($f-32)/9);

        echo "Esta é a temperatura em graus Farenheit: " . $f;
        echo "<br>";
        echo "Esta é a temperatura em graus Celsius: " . $c;
    }
    ?>
</body>
</html>