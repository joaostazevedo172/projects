<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exer 4 php </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite a distância total em Km: 
	<input type="text" name="txt_valor1" id="txt_valor1" >
	<br/>
	<br/>
	Digite a quantidade de combustível em litros: 
	<input type="text" name="txt_valor2" id="txt_valor2" >
	<br/>
    <br/>
    <input type="submit" name="result" value="enviar">
    <p id="operacao">Consumo médio em Km/l:</p>
    </form>

    <?php
	  if (isset ($_POST['txt_valor1']) and isset ($_POST['txt_valor2']) and isset  ($_POST['result']))
      {
          
              $a = $_POST['txt_valor1'];
              $b = $_POST['txt_valor2'];
              $result = $_POST['result'];

          function consumo ($a, $b)
          {
              

              $result = ($a/$b);

              echo $result;
              
          }

          echo consumo ($a, $b);
      
      
      }
	
?>
</body>
</html>
