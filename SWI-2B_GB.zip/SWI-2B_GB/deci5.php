<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão5 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite A: 
	<input type="text" name="n1">
	<br/>
	<br/>
	Digite B: 
	<input type="text" name="n2">
	<br/>
    <br/>
    <input type="submit" value="Calcular">
	<br><br>
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['n2']))
            {
				
					$val1 = $_POST['n1'];
   					$val2 = $_POST['n2'];

				if ($val1 < $val2)
                {
                    echo $val1. ", ". $val2;
                }
                else
                {
                    echo $val2. ", ". $val1;
                }
			
            
            }
	
?>
	

</body>
</html>
