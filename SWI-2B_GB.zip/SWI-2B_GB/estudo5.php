<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>salario</title>
</head>
<body>
    <form method="post">
        Digite quanto você ganha por hora:
        <br>
        <input type="text" name="hora">
        <br>
        Digite quantas horas você trabalha no mês:
        <br>
        <input type="text" name="mes">
        <br>
        <br>
        <input type="submit">
    </form>

    <?php

    if (isset ($_POST['hora']) and isset ($_POST['mes']))
    {
        $g_hora = $_POST['hora'];
        $h_mes = $_POST['mes'];
        
        echo "O salário do mês é: " . $g_hora * $h_mes;
    }

    ?>
</body>
</html>