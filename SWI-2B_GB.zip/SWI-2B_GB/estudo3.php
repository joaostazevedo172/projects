<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>soma</title>
</head>
<body>
    <form method="post">
        Digite um número:
        <input type="text" name="n1">
        <br>
        Digite outro número:
        <input type="text" name="n2">
        <br>
        <input type="submit" value="Somar">
    </form>

    <?php
    
    if (isset ($_POST['n1']) and isset ($_POST['n2']))
    {

    
        $num1 = $_POST['n1'];
        $num2 = $_POST['n2'];
        $soma = $num1 + $num2;

        echo "<br>";
        echo "O valor da soma é: " . $soma;
    }
    ?>
</body>
</html>