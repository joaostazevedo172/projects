<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão8</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite a sigla do Estado: 
	<input type="text" name="v1">
	<br><br>
    <input type="submit" value="Calcular" name="val">
	

	<?php

    if (isset ($_POST['v1']) and isset ($_POST['val']))
            {
				
					$a = $_POST['v1'];
                 
                    if ($a == "SP")
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "Paulista";
                    }
                    else if ($a == "RJ")
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "Carioca";
                    }
                    else
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "Outro Estado";
                    }
			
            
            }
	
?>
	

</body>
</html>
