<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão9</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite um número: 
	<input type="text" name="v1">
	<br><br>
    <input type="submit" value="Calcular" name="val">
	

	<?php

    if (isset ($_POST['v1']) and isset ($_POST['val']))
            {
				
					$a = $_POST['v1'];
                 
                    if ($a % 2 == 0)
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "O número é par";
                    }
                    else 
                    {
                        echo "<br>";
                        echo "<br>";
                        echo "O número é ímpar";
                    }
			
            
            }
	
?>
	

</body>
</html>
