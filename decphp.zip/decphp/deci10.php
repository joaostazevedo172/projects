<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> decisão10 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite X: 
	<input type="text" name="x">
	<br/>
	<br/>
	Digite Y: 
	<input type="text" name="y">
	<br/>
    <br/>
    Digite Z: 
	<input type="text" name="z">
    <br><br>
    <input type="submit" value="Verificar">
	</form>
	

	<?php

    if (isset ($_POST['x']) and isset ($_POST['y']) and isset ($_POST['z']))
            {
				
					$a = $_POST['x'];
   					$b = $_POST['y'];
    				$c =  $_POST['z'];

				if ($a == $b and $a == $c)
                {
                    echo "<br>";
                    echo "O triângulo é equilátero";
                }
                else if ($a == $b and $a != $c)
                {
                    echo "<br>";
                    echo "O triângulo é isósceles";
                }
                else
                {
                    echo "<br>";
                    echo "O triângulo é escaleno";
                }
			
            
            }
	
?>
	

</body>
</html>
