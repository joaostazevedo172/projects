<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico3 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite um número: 
	<input type="text" name="n1">
	<br><br>
    <input type="submit" value="Calcular" name="res">
	<br><br>
	15% do valor:
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['res']))
            {
				
					$a = $_POST['n1'];
    				$result = $_POST['res'];

				function porc ($a)
				{
					

					$result = ($a * 0.15);

					echo $result;
                	
				}

				echo porc ($a);
			
            
            }
	
?>
	

</body>
</html>
