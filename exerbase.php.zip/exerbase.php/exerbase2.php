<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico2 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite o primeiro número: 
	<input type="text" name="n1">
	<br/>
	<br/>
	Digite o segundo número: 
	<input type="text" name="n2">
	<br/>
    <br/>
    Digite o terceiro número: 
	<input type="text" name="n3">
    <br><br>
    <input type="submit" value="Calcular" name="res">
	<br><br>
	Média:
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['n2']) and isset ($_POST['n3']) and isset ($_POST['res']))
            {
				
					$val1 = $_POST['n1'];
   					$val2 = $_POST['n2'];
    				$val3 =  $_POST['n3'];
    				$result = $_POST['res'];

				function media ($val1, $val2, $val3)
				{
					

					$result = ($val1 + $val2 + $val3)/3;

					echo $result;
                	
				}

				echo media ($val1, $val2, $val3);
			
            
            }
	
?>
	

</body>
</html>
