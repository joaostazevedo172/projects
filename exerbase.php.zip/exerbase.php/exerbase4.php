<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico4 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite um número: 
	<input type="text" name="n1">
	<br><br>
    <input type="submit" value="Calcular" name="r">
	<br><br>
	</form>
	

	<?php

    if (isset ($_POST['n1']) and isset ($_POST['r']))
            {
				
					$a = $_POST['n1'];
    				$result = $_POST['r'];
                 

				function por ($a)
				{
					

					$result = ($a);

					echo "Este é 50% do valor: ". $result * 0.5;
                    echo "<br>";
                    echo "Este é 5% do valor: ". $result * 0.05;
                	
				}

				echo por ($a);
			
            
            }
	
?>
	

</body>
</html>
