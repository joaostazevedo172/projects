<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico5 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite o primeiro valor: 
	<input type="text" name="num1" >
	<br/>
	<br/>
	Digite o segundo valor: 
	<input type="text" name="num2" >
	<br/>
	<br/>
	<input type="submit" value="Calcular" name="result">
	<br><br>
	Soma dos quadrados:
    </form>

	<?php
	 if (isset ($_POST['num1']) and isset ($_POST['num2']))
	 {
		 
			$a = $_POST['num1'];
			$b = $_POST['num2'];
			

		 function quad ($c, $d)
		 {
			 
			$valor = ($c * $c);
			$valor2 = ($d * $d);
			return ($valor + $valor2);

			
			 
		 }

		 echo quad($a, $b);
		}
	
?>
</body>
</html>

