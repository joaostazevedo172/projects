<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exerbasico1</title>
</head>
<body>
<form method="post">
	Digite o primeiro número: 
	<input type="text" name="num1">
	<br/>
	<br/>
	Digite o segundo número: 
	<input type="text" name="num2">
	<br/>
    <br/>
    <input type="submit" value="Calcular" name="resul">
	<br><br>
	Resultado:
	</form>
	

    <?php

    if (isset ($_POST['num1']) and isset ($_POST['num2']) and isset ($_POST['resul']))
            {
				
					$a = $_POST['num1'];
   					$b = $_POST['num2'];
    				$result = $_POST['resul'];

				function soma ($a, $b)
				{
					

					$result = ($a + $b)*$a;

					echo $result;
                	
				}

				echo soma ($a, $b);
			
            
            }
	
?>
    
</body>
</html>