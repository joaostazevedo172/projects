<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico7 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite o primeiro valor: 
	<input type="text" name="nt1">
	<br/>
	<br/>
	Digite o segundo valor: 
	<input type="text" name="nt2">
	<br/>
    <br/>
    Digite o terceiro valor: 
	<input type="text" name="nt3">
	<br/>
	<br/>
	Média Ponderada:
	<br/>
	<br/>
    <input type="submit" value="Calcular" name="media">
	<br>
    </form>

	<?php

    if (isset ($_POST['nt1']) and isset ($_POST['nt2']) and isset ($_POST['nt3']) and isset ($_POST['media']))
            {
				
					$n1 = $_POST['nt1'];
   					$n2 = $_POST['nt2'];
    				$n3 =  $_POST['nt3'];
    				$md = $_POST['media'];

				function md ($n1, $n2, $n3)
				{
					

					$n1 = $n1 * 2;
                    $n2 = $n2 * 3;
                    $n3 = $n3 * 5;
                	
                    $md = (($n1 + $n2 + $n3)/10);

					echo $md;
				}

				echo md ($n1, $n2, $n3);
			
            
            }
	
?>

</body>
</html>
