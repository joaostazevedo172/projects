<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico6 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	
	<?php

  
				
					$nome = "Walter White";
    				$idade = 50;
                    $salario = 100;

				echo "Olá! Qual seu nome?";
                echo "<br>";
                echo "<br>";
                echo $nome;
                echo "<br>";
                echo "<br>";
                echo "Oi, ". $nome. "!". " Quantos anos você tem?";
                echo "<br>";
                echo "<br>";
                echo $idade;
                echo "<br>";
                echo "<br>";
                echo "Então você tem ". $idade. "!!!";
                echo "<br>";
                echo "<br>";
                echo "Quanta você ganha, ". $nome. "?";
                echo "<br>";
                echo "<br>";
                echo $salario;
                echo "<br>";
                echo "<br>";
                echo $salario."!". " Eu espero que seja por hora não por ano!!!!! rsrsrs";

	
?>
	

</body>
</html>
