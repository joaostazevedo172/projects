<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico8 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite o valor do produto: 
	<input type="text" name="p1">
	<br><br>
    <input type="submit" value="Calcular" name="pr">
	<br><br>
	Valor do produto com 16% de acréscimo parcelado em 10 vezes:
	</form>
	

	<?php

    if (isset ($_POST['p1']) and isset ($_POST['pr']))
            {
				
					$a = $_POST['p1'];
    				$result = $_POST['pr'];
                 

				function por ($a)
				{
					

					$result = ($a);

					$result =  $result * 0.16 + $result;
                    echo  "Resultado total: ". $result;
                    echo "<br>";
                    echo "Resultado parcelado em 10 vezes: ". $result / 10;
                    
                	
				}

				echo por ($a);
			
            
            }
	
?>
	

</body>
</html>
