<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> exerbasico9 </title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <form method="post">
	Digite a distância total em Km: 
	<input type="text" name="km" >
	<br/>
	<br/>
	Digite a quantidade de combustível em litros: 
	<input type="text" name="li" >
	<br/>
    <br/>
    <input type="submit" name="consumo" value="Enviar">
    <p id="operacao">Consumo médio em Km/l:</p>
    </form>

    <?php
	  if (isset ($_POST['km']) and isset ($_POST['li']) and isset  ($_POST['consumo']))
      {
          
              $a = $_POST['km'];
              $b = $_POST['li'];
              $result = $_POST['consumo'];

          function consumo ($a, $b)
          {
              

              $result = ($a/$b);

              echo $result;
              
          }

          echo consumo ($a, $b);
      
      
      }
	
?>
</body>
</html>
