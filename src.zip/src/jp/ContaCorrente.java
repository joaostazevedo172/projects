/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jp;

/**
 *
 * @author JOÃO
 */
public class ContaCorrente {

    public float saldo;

    public void definirSaldoInicial(float valor) {
        saldo = valor;
    }

    public void depositar(float valor) {
        saldo += valor;
    }

    public boolean sacar(float valor) {
        if (valor > saldo) {
            System.out.println("Saldo insuficiente. Saque não realizado");
            return false;
        } else {
            saldo -= valor;
            return true;
        }
    }

    public float getSaldo() {
        return saldo;
    }
}
