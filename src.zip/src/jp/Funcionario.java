/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jp;

/**
 *
 * @author JOÃO
 */
public class Funcionario {
    public String nome;
    public String sobrenome;
    public int horasTrabalhadas;
    public float valorPorHora;
    
    public String nomeCompleto(){
        return nome + " " + sobrenome;
    }
    
    public float calcularSalario(){
        return horasTrabalhadas * valorPorHora;
    }
    
    public void incrementarHoras (int horas) {
        horasTrabalhadas += horas;
    }
    
    public void setNome (String nome){
        this.nome = nome;
    }
    
    public void setSobrenome (String sobrenome){
        this.sobrenome = sobrenome;
    }
    
    public void setHorasTrabalhadas(int horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }
    
    public void setValorPorHora(float valorPorHora) {
        this.valorPorHora = valorPorHora;
    }
}
