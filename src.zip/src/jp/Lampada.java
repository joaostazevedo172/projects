/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jp;

/**
 *
 * @author JOÃO
 */
public class Lampada {

    public boolean acesa;
    public int potencia;

    public void acender() {
        acesa = true;
    }

    public void apagar() {
        acesa = false;
    }

    public void informarSituacao() {
        if (acesa) {
            System.out.println("A luz está acesa");
        } else {
            System.out.println("A luz está apagada");
        }
    }

    public void informarPotencia() {
        System.out.println("A potência da lamapada é " + potencia);
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }
}
