/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jp;

/**
 *
 * @author JOÃO
 */
public class Data {

    public int dia;
    public int mes;
    public int ano;

    public void escreverAData() {
        System.out.println(dia + "/" + mes + "/" + ano);
    }

    public void escreverOMes() {
        String[] meses = {"", "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        System.out.println(meses[mes]);
    }

    public void verificarAnoBissexto() {
        if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
            System.out.println("O ano é bissexto");
        } else {
            System.out.println("O ano não é bissexto");
        }
    }

    public void quantoFaltaFimDoAno() {
        // Considerando um ano não bissexto para simplificar
        int diasAteFimDoAno = 365 - calcularDiasTranscorridos();
        System.out.println("Faltam " + diasAteFimDoAno + " dias para o fim do ano");
    }

    private int calcularDiasTranscorridos() {
        int diasNoMes[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int diasTranscorridos = dia;
        for (int i = 1; i < mes; i++) {
            diasTranscorridos += diasNoMes[i];
        }
        return diasTranscorridos;
    }
}
