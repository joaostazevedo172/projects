/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jp;

/**
 *
 * @author JOÃO
 */
public class Pessoa {

    public String nome;
    public int idade;

    public void dizerONome() {
        System.out.println("Oi, meu nome é " + nome);
    }

    public void dizerAIdade() {
        System.out.println("Oi, eu tenho " + idade + " anos");
    }

    public void dizerAIdade2() {
        System.out.println("Oi, agora eu tenho " + idade + " anos");
    }

    public void fazerAniversario() {
        System.out.println("Feliz Aniversário!");
        idade++;
    }

    public void SetNome(String nome) {
        this.nome = nome;
    }

    public void SetIdade(int idade) {
        this.idade = idade;
    }
}
