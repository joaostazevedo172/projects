/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jp;

/**
 *
 * @author JOÃO
 */
public class Jp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pessoa pessoa = new Pessoa();

        pessoa.SetNome("João Pedro");
        pessoa.SetIdade(17);

        pessoa.dizerONome();
        pessoa.dizerAIdade();
        pessoa.fazerAniversario();
        pessoa.dizerAIdade2();

        Lampada lampada = new Lampada();

        lampada.acender();
        lampada.informarSituacao();
        lampada.apagar();
        lampada.informarSituacao();
        lampada.setPotencia(60);
        lampada.informarPotencia();

        Data data = new Data();

        data.dia = 5;
        data.mes = 12;
        data.ano = 2023;
        data.escreverAData();
        data.escreverOMes();
        data.verificarAnoBissexto();
        data.ano = 2024;
        data.verificarAnoBissexto();
        data.quantoFaltaFimDoAno();
        data.ano = 2023;
        data.quantoFaltaFimDoAno();

        ContaCorrente novaConta = new ContaCorrente();

        novaConta.definirSaldoInicial(1000);

        System.out.println("Saldo inicial: R$" + novaConta.getSaldo());

   
        boolean saqueRealizado = novaConta.sacar(500);
        if (saqueRealizado) {
            System.out.println("Saque de R$500 realizado. Saldo restante: R$" + novaConta.getSaldo());
        }

        novaConta.depositar(50);
        System.out.println("Depósito de R$50 realizado. Saldo atual: R$" + novaConta.getSaldo());

        saqueRealizado = novaConta.sacar(600);
        if (saqueRealizado) {
            System.out.println("Saque de R$600 realizado. Saldo restante: R$" + novaConta.getSaldo());
        }
        
         Funcionario novoFuncionario = new Funcionario();

        // Atribuir valores
        novoFuncionario.setNome("Luis");
        novoFuncionario.setSobrenome("Silva");
        novoFuncionario.setHorasTrabalhadas(10);
        novoFuncionario.setValorPorHora(25.50f);

        System.out.println("Nome completo: " + novoFuncionario.nomeCompleto());

        System.out.println("Salário: R$" + novoFuncionario.calcularSalario());

        novoFuncionario.incrementarHoras(8);

        System.out.println("Novo salário: R$" + novoFuncionario.calcularSalario());

    }

}
