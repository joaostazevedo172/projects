CREATE DATABASE mercado;

USE mercado;

CREATE TABLE unidade_de_medida (
tamanho INT NOT NULL PRIMARY KEY,
unidade INT,
metro INT,
quilograma INT, 
litro INT
);

CREATE TABLE produto (
ref_ordem INT NOT NULL PRIMARY KEY,
estoque_minimo VARCHAR (750),
estoque_maximo VARCHAR (2000),
tamanho_produto INT,
FOREIGN KEY (tamanho_produto) REFERENCES unidade_de_medida (tamanho)
);

CREATE TABLE procedencia (
cnpj VARCHAR (14) NOT NULL PRIMARY KEY,
nome VARCHAR (50),
estoque_fornecido BIGINT,
produto_fornecido INT,
FOREIGN KEY (produto_fornecido) REFERENCES produto (ref_ordem)
);

CREATE TABLE dat (
estoque_obtido BIGINT NOT NULL PRIMARY KEY,
dia_entrada DATE,
dia_saída DATE,
estoque_retirado BIGINT,
fornecedor VARCHAR (14),
FOREIGN KEY (fornecedor) REFERENCES procedencia (cnpj)
); 
