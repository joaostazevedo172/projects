CREATE DATABASE loja_de_livros;

USE loja_de_livros;


CREATE TABLE autor (
biografia VARCHAR (1500) NOT NULL PRIMARY KEY,
nome VARCHAR (50),
nascimento DATE, 
RG VARCHAR (9),
cep VARCHAR (8) 
); 

CREATE TABLE funcionarios (
id_funcionario INT NOT NULL PRIMARY KEY,
nome VARCHAR (50),
nascimento DATE,
carga_horario DECIMAL,
rg VARCHAR (9),
cep VARCHAR (8),
telefone INT,
email VARCHAR (50),
cpf VARCHAR (11),
carteira_de_trabalho TEXT
);
 
CREATE TABLE livro (
isbn VARCHAR (13) NOT NULL PRIMARY KEY,
nome VARCHAR (50),
ano DATE,
preco DECIMAL,
idioma VARCHAR (20),
informacao_autor VARCHAR (1500),
nome_autor VARCHAR (50),
FOREIGN KEY (informacao_autor) REFERENCES autor (biografia)
);



CREATE TABLE cliente (
id_cliente INT NOT NULL PRIMARY KEY,
nome VARCHAR (50),
cpf VARCHAR (11),
cep VARCHAR (8),
nascimento DATE,
email VARCHAR (50),
rg VARCHAR (9),
telefone INT
);

CREATE TABLE editora (
cnpj VARCHAR (14) NOT NULL PRIMARY KEY,
nome VARCHAR (50),
telefone INT,
cep VARCHAR (8),
email VARCHAR (50),
cod_livro VARCHAR (13),
FOREIGN KEY (cod_livro) REFERENCES livro (isbn)
);

CREATE TABLE venda (
nota_fiscal VARCHAR (70) NOT NULL PRIMARY KEY,
pagamento DECIMAL,
dia_da_compra DATE,
cod_livro VARCHAR (13), 
cod_cliente INT,
cod_funcionario INT,
cod_editora VARCHAR (14),
FOREIGN KEY (cod_livro) REFERENCES livro (isbn),
FOREIGN KEY (cod_cliente) REFERENCES cliente (id_cliente),
FOREIGN KEY (cod_funcionario) REFERENCES funcionarios (id_funcionario),
FOREIGN KEY (cod_editora) REFERENCES editora (cnpj)
); 


