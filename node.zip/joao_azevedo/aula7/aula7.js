var http = require('http');
var url = require('url');
var fs = require('fs');

http.createServer(function (req, res) {
  var q = url.parse(req.url, true);
  var filename = "." + q.pathname;

  if (q.pathname === '/index.html') {
    filename = "./index.html";
  } else if (q.pathname === '/sobre.html') {
    filename = "./sobre.html";
  } else {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write('<meta charset="utf-8"/>');
    return res.end("Página não encontrada");
  }

  fs.readFile(filename, function(err, data) {
    if (err) {

      res.writeHead(200, {'Content-Type': 'text/html'});
      return res.end("Página não encontrada");
    } 
  
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    return res.end();
  });
}).listen(80);
