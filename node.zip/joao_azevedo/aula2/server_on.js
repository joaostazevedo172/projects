var http = require ('http');
var atendeRequisicao = function (request,response){
    response.writeHead(200, {"Content-Type": "text/html"});
    response.write ("<h1>Hello Jon!</h1>");
    response.write ("<h1>Segunda linha</h1>");
    response.end();
}

var server = http.createServer(atendeRequisicao);
var servidorLigou = function (){
    console.log('Servidor Jon rodando!');
}

server.listen(80, servidorLigou);