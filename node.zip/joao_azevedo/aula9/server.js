const http = require('http');
const url = require('url');
const config  = require('./config.json');
const fileHandler = require('./filehandler');


const server = http.createServer(onRequest);

function onRequest(req, res){
    const parsedUrl = url.parse(req.url);
    let filename =  parsedUrl.pathname;
    let fullPath = __dirname + config.rootFolder + filename;
    const extension = filename.split('.').pop();

    if (!fullPath.startsWith(__dirname + config.rootFolder)){
        res.writeHead(403);
        return res.end('Forbidden');
    }

    if (filename === '/'){
        filename = config.defaultIndex;
        fullPath = __dirname + config.rootFolder + filename;
    }

    fileHandler(fullPath, function (data){
        res.writeHead(200, {
            'Content-Type': config.types[extension] || 'text/html',
            'Content-Length': data.length
        });
        res.end(data);
    }, function (err){
        console.error('Erro ao ler arquivo:', err);

        res.writeHead(404, {'Content-Type': 'text/html'});
        res.write('<meta charset ="utf-8 />');
        res.write('<h1>Página de Erro - Arquivo não encotrado</h1>');
        res.end();
    });
    
    
}

module.exports = server;