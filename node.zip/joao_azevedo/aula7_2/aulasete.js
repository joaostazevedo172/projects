var http = require('http');
var fs = require('fs');

var server = http.createServer(function (req, res) {
    if (req.url == "/" || req.url == "/index") {
        console.log('/');
        fs.readFile('index.html', function (err, data) {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.write('<meta charset="utf-8"/>');
                res.write('<h1>Página não encontrada :(</h1>');
                console.log('Erro ao ler arquivo');
                return res.end();
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write('<meta charset="utf-8"/>');
            res.write(data);
            return res.end();
        });
    } else if (req.url == "/sobre") {
        console.log('sobre');
        fs.readFile('sobre.html', function (err, data) {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.write('<meta charset="utf-8"/>');
                res.write('<h1>Página não encontrada :(</h1>');
                console.log('Erro ao ler arquivo');
                return res.end();
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write('<meta charset="utf-8"/>');
            res.write(data);
            return res.end();
        });
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.write('<meta charset="utf-8"/>');
        res.write('<h1>Página não encontrada :(</h1>');
        console.log('Não Encontrou');
        return res.end();
    }
});

server.listen(80, function () {
    console.log('Servidor Rodando!');
});
